package com.yasin.produits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProduitsApplicationTests {

	@Test
	void contextLoads() {
	}

}
